package com.inventory;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.inventory.CarDao;


public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        System.out.println("My Program has started: ");
        
    	ApplicationContext context = new ClassPathXmlApplicationContext("bean.xml");
    	CarDao dao= context.getBean("carDao",CarDao.class);
    	System.out.println(dao);
    	System.out.println("Enter details: ");
    	Scanner scan = new Scanner(System.in);
    	System.out.println("Enter Car Make: ");
    	String carMake = scan.nextLine();
    	String carModel=scan.next();
    	int carYear=scan.nextInt();
    	float carPrice=scan.nextFloat();
    	CarDetails details = new CarDetails();
    	details.setMake(carMake);
    	details.setModel(carModel);
    	details.setYear(carYear);
    	details.setPrice(carPrice);
    	dao.saveDetails(details);
    	List<CarDetails> list = dao.getCarDetails();
    	for(CarDetails detail : list)
    	{
    		System.out.println(detail);
    		
    	}
    }
}
