package com.inventory;
import lombok.*;
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CarDetails 
{
	private String Make;
	private String Model;
	private int Year;
	private float Price;
}
