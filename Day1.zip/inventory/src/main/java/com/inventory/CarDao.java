package com.inventory;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.inventory.CarDetails;

public class CarDao 
{
	@Autowired
	private JdbcTemplate template;  

	public void setTemplate(JdbcTemplate template) {  
	    this.template = template;  
	} 
	public JdbcTemplate getTemplate()
	{
		return template;
	}
	

	public void saveDetails(CarDetails details)
	{
	String query="insert into cars(Make,Model,Year,Price) values('"+details.getMake()+"','"+details.getModel()+"',"+details.getYear()+","+details.getPrice()+")";
	template.update(query);
	System.out.println("Details added : ");
	
	}
	public List<CarDetails> getCarDetails()
	{
		return template.query("select * from car", new RowMapper<CarDetails>() {
			public CarDetails mapRow(ResultSet rs,int rownumber) throws SQLException{
				CarDetails details = new CarDetails();
				details.setMake(rs.getString(1));
				details.setModel(rs.getString(2));
				details.setYear(rs.getInt(3));
				details.setPrice(rs.getFloat(4));
				return details;
			}
			
		});
			
	}
	
	
}
